    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Thank You</title>
        <style>
            * {
                font-family: 'Poppins', sans-serif;
            }
        </style>
    </head>

    <body>
        <img src="https://www.gifcen.com/wp-content/uploads/2021/05/thank-you-gif-5.gif" alt="" style="display: block; margin-left: auto; margin-right: auto; margin-top: 12%;">
        <br>
        <center>
            <h1>Please Stay With Us</h1>
            <fieldset style="width:10%">
                <a href="./home.php" style="text-decoration:none; color:black"><i class="fas fa-arrow-circle-left"></i>&nbsp;Back</a>
            </fieldset>
        </center>

    </body>

    </html>